You can run this using 2 methods

#1 Using Command Line
Step 1: Open terminal at the location where index.js exists
Step 2: Run `node index.js`. node must be installed on the device.
The Output will be visible in that window

#2 Using Browser
Step 1: Simply open index.html using a browser
Step 2: Press F12 to open Developer Options
Step 3: You can see the output in the Console

The Code is explained by giving comments for each line of the code.
The Code is divided into three phase
1. Defining Base class
2. Defining Sub class with inheritance from Base class.
3. Creating Objects and Testing the code.