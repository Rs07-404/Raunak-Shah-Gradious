export type Item = {
    id:number,
    src: string,
    status: string,
    alt: string;
}