
export type appointmentType = {
    patientName: string,
    age: any,
    gender: string,
    status: string,
    time: any,
    date: any,
    phoneNumber: string,
    doctorName: string,
}