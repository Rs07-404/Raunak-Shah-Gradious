const pathVariable = process.env.PATH.split(';');
console.log("Path Environment Variables", pathVariable);