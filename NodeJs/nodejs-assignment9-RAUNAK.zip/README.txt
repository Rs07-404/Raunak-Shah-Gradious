• main File: server.js
• Run npm start in the project folder to start the server adn Just Visit http://localhost:5000/ on a browser to access UI
• Note: Replace the database `host`, `user` and `Password` in the code with your database host, username and password.
