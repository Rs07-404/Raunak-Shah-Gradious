run server.js by using `npm start`
and visit http://localhost:5000/

• click on the `browse` button to upload the file.

• If there is any validation then it will appear in red color below uploaded file name box.

• The link will apprear infront of `Link: `.