ASGN2238 Raunak Shah
start the API-SERVER by using 
npm start

Endpoints for localhost with port 5000

• http://localhost:5000/sales/percentage-change
• http://localhost:5000/sales/highest-business-date
• http://localhost:5000/sales/business-improvement
• http://localhost:5000/sales/percentage-change-wholesale
• http://localhost:5000/sales/customers


Not Necessary Note:
Use "JSON Viewer Pro" Extension in browser to make the json more viewable
Link: https://chromewebstore.google.com/detail/json-viewer-pro/eifflpmocdbdmepbjaopkkhbfmdgijcc